//
//  DatabaseManager.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation
import RealmSwift

protocol RelamSetupManager {
    var realm: Realm { get }
    func write(writeClosure: () -> Void)
    func removeAllData()
}

extension RelamSetupManager {
    var realm: Realm {
        do {
            let realm = try Realm()
            return realm
        } catch {
            //debugPrint(error.localizedDescription)
        }
        return self.realm
    }
   
    func write(writeClosure: () -> Void) {
        do {
            try realm.write {
                writeClosure()
            }
        } catch {
            //debugPrint(error.localizedDescription)
        }
    }
    
    func removeAllData() {
        write {
            realm.deleteAll()
        }
    }
}
