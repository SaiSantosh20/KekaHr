//
//  HTTPClient.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

protocol HTTPClient {
    func request<T: Decodable>(request: URLRequest,
                               completion: @escaping (Result<T, HTTPError>) -> Void)
    func makeURLRequest(url: URL,
                            method: String,
                            headers: [String: String]?,
                            queryParams: [URLQueryItem]?,
                            body: Data?) -> URLRequest?
}

extension HTTPClient {
    func makeURLRequest(url: URL,
                        method: String,
                        headers: [String: String]? = nil,
                        queryParams: [URLQueryItem]? = nil,
                        body: Data? = nil) -> URLRequest? {
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        components?.queryItems = queryParams
        guard let finalURL = components?.url else {
            return nil
        }
        var request = URLRequest(url: finalURL)
        request.httpMethod = method
        request.allHTTPHeaderFields = headers
        request.httpBody = body
        return request
    }
}

class UrlSessionAPIFetcher: HTTPClient {
    func request<T: Decodable>(request: URLRequest, completion: @escaping (Result<T, HTTPError>) -> Void) {
        URLSession.shared.dataTask(with: request) { data, urlResponse, error in
            guard let urlResponse = urlResponse as? HTTPURLResponse, (200...299).contains(urlResponse.statusCode) else {
                completion(.failure(.failedResponse))
                return
            }
            guard let data = data else {
                completion(.failure(.invalidData))
                return
            }
            do {
                let decodedData = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(.failedDecoding))
            }
        }.resume()
    }
}

