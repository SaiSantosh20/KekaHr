//
//  HTTPMethod.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

enum HTTPMethod: String {
    case GET = "GET"
    case POST = "POST"
    case DELETE = "DELETE"
    case PUT = "PUT"
    case PATCH = "PATCH"

    func callAsFunction() -> String {
        rawValue
    }
}
