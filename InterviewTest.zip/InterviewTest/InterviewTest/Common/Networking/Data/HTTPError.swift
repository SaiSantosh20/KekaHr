//
//  HTTPError.swift
//  InterviewTest
//
// Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

enum HTTPError: Error {
    case failedResponse
    case failedDecoding
    case invalidUrl
    case invalidData 
}
