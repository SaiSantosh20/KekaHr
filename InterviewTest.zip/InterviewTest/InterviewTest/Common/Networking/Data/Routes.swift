//
//  Routes.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

enum Routes: String {
    case articlesearch = "/svc/search/v2/articlesearch.json"

    func callAsFunction() -> String {
        rawValue
    }
}
