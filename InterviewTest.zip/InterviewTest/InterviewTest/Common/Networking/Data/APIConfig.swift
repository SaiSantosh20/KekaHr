//
//  APIConfig.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

struct APIConfig {
    let scheme: String
    let host: String
}
