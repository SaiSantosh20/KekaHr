//
//  NetworkMonitor.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Combine
import Network

import Combine
import Network

import Combine
import Network

class NetworkReachability {
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "NetworkReachability", qos: .background)
    
    // Publisher for network status changes
    private let isConnectedSubject = CurrentValueSubject<Bool, Never>(false)
    
    var isConnectedPublisher: AnyPublisher<Bool, Never> {
        return isConnectedSubject.eraseToAnyPublisher()
    }
    
    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            guard let self = self else { return }
            let isConnected = path.status == .satisfied
            debugPrint("Monitor network: \(isConnected)")
            self.isConnectedSubject.send(isConnected)
        }
        
        monitor.start(queue: queue)
    }
}


