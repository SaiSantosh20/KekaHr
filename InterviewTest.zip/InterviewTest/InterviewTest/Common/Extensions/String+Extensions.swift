//
//  String+Extensions.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

extension String {
    func toDate(format: String, timeZone: TimeZone = TimeZone(abbreviation: "UTC")!) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = timeZone
        return dateFormatter.date(from: self)
    }
}

