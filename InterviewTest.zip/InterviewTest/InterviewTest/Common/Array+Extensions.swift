//
//  Array+Extensions.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
