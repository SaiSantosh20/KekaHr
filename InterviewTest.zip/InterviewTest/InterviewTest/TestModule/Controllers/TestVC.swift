//
//  ViewController.swift
//  TestVC
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import UIKit


class TestVC: UIViewController {
    private var viewModel: TestVCViewModel?
    private var tblHelper: TestVcTableviewCellHelper?
    
    @IBOutlet weak var articleTblView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = TestVCViewModel()
        tblHelper = TestVcTableviewCellHelper()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.intialSetup()
    }
}


extension TestVC: TestVCViewModelDelegate {
    private func intialSetup() {
        self.registerTableviewProtocols()
        viewModel?.fetchDetails()
        viewModel?.delegate = self
        articleTblView.rowHeight = UITableView.automaticDimension
        articleTblView.estimatedRowHeight = 200
    }
    
    private func registerTableviewProtocols() {
        tblHelper?.registerCells(tblView: articleTblView)
        self.articleTblView.delegate = self
        self.articleTblView.dataSource = self
    }
    
    func reloadTheList() {
        DispatchQueue.main.async {
            self.articleTblView.reloadData()
        }
    }
    
    func updateNetwork(with status: Bool) {
        if status == false {
            self.showToast(message: "Network failed!!!", font: .systemFont(ofSize: 12))
        }
    }
}

extension TestVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel?.articlesList.count ?? 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return TestVcTableviewCellNames.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cellInfo = TestVcTableviewCellNames.allCases[safe: indexPath.section] {
            switch cellInfo {
            case .articleDetailCell:
                if let model = self.viewModel?.articlesList[safe: indexPath.row] {
                    guard let cell = tableView.dequeueReusableCell(withIdentifier: cellInfo.reuseIdentifier, for: indexPath) as? TestVcTblViewDetailCell else { return UITableViewCell() }
                    //debugPrint(viewModel?.articlesList.count ?? "Count is not detected")
                    cell.configureCell(model: model)
                    return cell
                }
            }
        }
        return UITableViewCell()
    }
    
}


