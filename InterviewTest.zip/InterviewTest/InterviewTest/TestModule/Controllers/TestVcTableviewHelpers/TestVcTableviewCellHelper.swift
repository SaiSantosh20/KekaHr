//
//  TestVcTableviewCellHelper.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import  UIKit

enum TestVcTableviewCellNames: CaseIterable {
    case articleDetailCell
    
    var reuseIdentifier: String {
        switch self {
        case .articleDetailCell:
            return String(describing: TestVcTblViewDetailCell.self)
        }
    }
}

class TestVcTableviewCellHelper {
    private var cellNames = TestVcTableviewCellNames.allCases.map { $0.reuseIdentifier }
    func registerCells(tblView: UITableView) {
        for cellName in cellNames {
            tblView.register(UINib(nibName: cellName, bundle: nil), forCellReuseIdentifier: cellName)
        }
    }
    
    func numberOfRows() -> Int {
        return TestVcTableviewCellNames.allCases.count
    }
    
}
