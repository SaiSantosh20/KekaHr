//
//  ArticlesDatabaseManager+Extension.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

//MARK: CONVERSION HELPER FUNCTIONS
extension ArticlesRealmManager {
    func fromCodable(_ codable: Doc) -> ArticlesDataRealmObject {
        let realmObject = ArticlesDataRealmObject()
        
        // Map properties
        realmObject.abstract = codable.abstract
        realmObject.webURL = codable.webURL
        realmObject.snippet = codable.snippet 
        realmObject.leadParagraph = codable.leadParagraph 
        realmObject.printSection = codable.printSection
        realmObject.printPage = codable.printPage
        realmObject.source = codable.source?.rawValue
        
        // Map multimedia
        if let multimedia = codable.multimedia {
            for item in multimedia {
                let articleMultimedia = ArticleMultimedia()
                articleMultimedia.rank = item.rank ?? 0
                articleMultimedia.subtype = item.subtype
                articleMultimedia.caption = item.caption
                articleMultimedia.credit = item.credit
                articleMultimedia.type = item.type?.rawValue
                articleMultimedia.url = item.url
                articleMultimedia.height = item.height ?? 0
                articleMultimedia.width = item.width ?? 0
                articleMultimedia.subType = item.subType
                articleMultimedia.cropName = item.cropName
                realmObject.multimedia.append(articleMultimedia)
            }
        }
        
        // Map headline
        if let headline = codable.headline {
            let articleHeadline = ArticleHeadline()
            articleHeadline.main = headline.main
            articleHeadline.kicker = headline.kicker
            articleHeadline.contentKicker = headline.contentKicker
            articleHeadline.printHeadline = headline.printHeadline
            articleHeadline.name = headline.name
            articleHeadline.seo = headline.seo
            articleHeadline.sub = headline.sub
            realmObject.headline = articleHeadline
        }
        
        // Map keywords
        if let keywords = codable.keywords {
            for keyword in keywords {
                let articleKeyword = ArticleKeyword()
                articleKeyword.name = keyword.name?.rawValue
                articleKeyword.value = keyword.value
                articleKeyword.rank = keyword.rank ?? 0
                articleKeyword.major = keyword.major?.rawValue
                realmObject.keywords.append(articleKeyword)
            }
        }
        
        realmObject.pubDate = codable.pubDate
        realmObject.documentType = codable.documentType?.rawValue
        realmObject.newsDesk = codable.newsDesk?.rawValue
        realmObject.sectionName = codable.sectionName?.rawValue
        realmObject.subsectionName = codable.subsectionName?.rawValue
        
        // Map byline
        if let byline = codable.byline {
            let articleByline = ArticleByline()
            articleByline.original = byline.original
            if let persons = byline.person {
                for person in persons {
                    let articlePerson = ArticlePerson()
                    articlePerson.firstname = person.firstname
                    articlePerson.middlename = person.middlename
                    articlePerson.lastname = person.lastname
                    articlePerson.qualifier = person.qualifier
                    articlePerson.title = person.title
                    articlePerson.role = person.role
                    articlePerson.organization = person.organization
                    articlePerson.rank = person.rank ?? 0
                    articleByline.person.append(articlePerson)
                }
            }
            articleByline.organization = byline.organization
            realmObject.byline = articleByline
        }
        
        realmObject.typeOfMaterial = codable.typeOfMaterial
        realmObject.wordCount = codable.wordCount ?? 0
        realmObject.uri = codable.uri
        
        return realmObject
    }
    
    func convertToDoc(realmObject: ArticlesDataRealmObject) -> Doc {
        var multimediaArray: [Multimedia]? = nil
        if !realmObject.multimedia.isEmpty {
            multimediaArray = realmObject.multimedia.map { multimedia in
                return Multimedia(rank: multimedia.rank,
                                  subtype: multimedia.subtype,
                                  caption: multimedia.caption,
                                  credit: multimedia.credit,
                                  type: TypeEnum.image,
                                  url: multimedia.url,
                                  height: multimedia.height,
                                  width: multimedia.width,
                                  legacy: nil,
                                  subType: multimedia.subType,
                                  cropName: multimedia.cropName)
            }
        }
        
        var keywordsArray: [Keyword]? = nil
        if !realmObject.keywords.isEmpty {
            keywordsArray = realmObject.keywords.map { keyword in
                return Keyword(name: Name(rawValue: keyword.name ?? ""),
                               value: keyword.value,
                               rank: keyword.rank,
                               major: Major.n)
            }
        }
        
        var personArray: [Person]? = nil
        if let byline = realmObject.byline {
            personArray = byline.person.map { person in
                return Person(firstname: person.firstname ?? "",
                              middlename: person.middlename,
                              lastname: person.lastname,
                              qualifier: person.qualifier,
                              title: person.title,
                              role: person.role,
                              organization: person.organization,
                              rank: person.rank)
            }
        }
        
        return Doc(abstract: realmObject.abstract,
                   webURL: realmObject.webURL,
                   snippet: realmObject.snippet,
                   leadParagraph: realmObject.leadParagraph,
                   printSection: realmObject.printSection,
                   printPage: realmObject.printPage,
                   source: Source.theNewYorkTimes,
                   multimedia: multimediaArray,
                   headline: Headline(main: realmObject.headline?.main,
                                      kicker: realmObject.headline?.kicker,
                                      contentKicker: realmObject.headline?.contentKicker,
                                      printHeadline: realmObject.headline?.printHeadline,
                                      name: realmObject.headline?.name,
                                      seo: realmObject.headline?.seo,
                                      sub: realmObject.headline?.sub),
                   keywords: keywordsArray,
                   pubDate: realmObject.pubDate,
                   documentType: DocumentType.article,
                   newsDesk: NewsDesk(rawValue: realmObject.newsDesk ?? ""),
                   sectionName: SectionName(rawValue: realmObject.sectionName ?? ""),
                   subsectionName: SubsectionName(rawValue: realmObject.subsectionName ?? ""),
                   byline: Byline(original: realmObject.byline?.original,
                                  person: personArray,
                                  organization: realmObject.byline?.organization),
                   typeOfMaterial: realmObject.typeOfMaterial,
                   id: realmObject.id,
                   wordCount: realmObject.wordCount,
                   uri: realmObject.uri)
    }

    

}
