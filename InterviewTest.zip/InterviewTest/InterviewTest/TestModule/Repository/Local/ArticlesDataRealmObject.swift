//
//  ArticlesDataRealmObject.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import RealmSwift

class ArticlesDataRealmObject: Object {
    @objc dynamic var id: String = UUID().uuidString
    @objc dynamic var abstract: String?
    @objc dynamic var webURL: String?
    @objc dynamic var snippet: String = ""
    @objc dynamic var leadParagraph: String = ""
    @objc dynamic var printSection: String?
    @objc dynamic var printPage: String?
    @objc dynamic var source: String?
    var multimedia = List<ArticleMultimedia>()
    @objc dynamic var headline: ArticleHeadline?
    var keywords = List<ArticleKeyword>()
    @objc dynamic var pubDate: String?
    @objc dynamic var documentType: String?
    @objc dynamic var newsDesk: String?
    @objc dynamic var sectionName: String?
    @objc dynamic var subsectionName: String?
    @objc dynamic var byline: ArticleByline?
    @objc dynamic var typeOfMaterial: String?
    @objc dynamic var wordCount: Int = 0
    @objc dynamic var uri: String?

    override static func primaryKey() -> String? {
        return "id"
    }
    
    convenience init(abstract: String?, webURL: String?, snippet: String, leadParagraph: String, printSection: String?, printPage: String?, source: String?, multimedia: List<ArticleMultimedia>, headline: ArticleHeadline?, keywords: List<ArticleKeyword>, pubDate: String?, documentType: String?, newsDesk: String?, sectionName: String?, subsectionName: String?, byline: ArticleByline?, typeOfMaterial: String?, wordCount: Int, uri: String?) {
        self.init()
        self.abstract = abstract
        self.webURL = webURL
        self.snippet = snippet
        self.leadParagraph = leadParagraph
        self.printSection = printSection
        self.printPage = printPage
        self.source = source
        self.multimedia = multimedia
        self.headline = headline
        self.keywords = keywords
        self.pubDate = pubDate
        self.documentType = documentType
        self.newsDesk = newsDesk
        self.sectionName = sectionName
        self.subsectionName = subsectionName
        self.byline = byline
        self.typeOfMaterial = typeOfMaterial
        self.wordCount = wordCount
        self.uri = uri
    }
}

class ArticleHeadline: Object {
    @objc dynamic var main: String?
    @objc dynamic var kicker: String?
    @objc dynamic var contentKicker: String?
    @objc dynamic var printHeadline: String?
    @objc dynamic var name: String?
    @objc dynamic var seo: String?
    @objc dynamic var sub: String?
    
    convenience init(main: String?, kicker: String?, contentKicker: String?, printHeadline: String?, name: String?, seo: String?, sub: String?) {
        self.init()
        self.main = main
        self.kicker = kicker
        self.contentKicker = contentKicker
        self.printHeadline = printHeadline
        self.name = name
        self.seo = seo
        self.sub = sub
    }
}

class ArticleKeyword: Object {
    @objc dynamic var name: String?
    @objc dynamic var value: String?
    @objc dynamic var rank: Int = 0
    @objc dynamic var major: String?
    
    convenience init(name: String?, value: String?, rank: Int, major: String?) {
        self.init()
        self.name = name
        self.value = value
        self.rank = rank
        self.major = major
    }
}

class ArticleMultimedia: Object {
    @objc dynamic var rank: Int = 0
    @objc dynamic var subtype: String?
    @objc dynamic var caption: String?
    @objc dynamic var credit: String?
    @objc dynamic var type: String?
    @objc dynamic var url: String?
    @objc dynamic var height: Int = 0
    @objc dynamic var width: Int = 0
    @objc dynamic var subType: String?
    @objc dynamic var cropName: String?
    
    convenience init(rank: Int, subtype: String?, caption: String?, credit: String?, type: String?, url: String?, height: Int, width: Int, subType: String?, cropName: String?) {
        self.init()
        self.rank = rank
        self.subtype = subtype
        self.caption = caption
        self.credit = credit
        self.type = type
        self.url = url
        self.height = height
        self.width = width
        self.subType = subType
        self.cropName = cropName
    }
}

class ArticleByline: Object {
    @objc dynamic var original: String?
    var person = List<ArticlePerson>()
    @objc dynamic var organization: String?
    
    convenience init(original: String?, person: List<ArticlePerson>, organization: String?) {
        self.init()
        self.original = original
        self.person = person
        self.organization = organization
    }
}

class ArticlePerson: Object {
    @objc dynamic var firstname: String?
    @objc dynamic var middlename: String?
    @objc dynamic var lastname: String?
    @objc dynamic var qualifier: String?
    @objc dynamic var title: String?
    @objc dynamic var role: String?
    @objc dynamic var organization: String?
    @objc dynamic var rank: Int = 0
    
    convenience init(firstname: String?, middlename: String?, lastname: String?, qualifier: String?, title: String?, role: String?, organization: String?, rank: Int) {
        self.init()
        self.firstname = firstname
        self.middlename = middlename
        self.lastname = lastname
        self.qualifier = qualifier
        self.title = title
        self.role = role
        self.organization = organization
        self.rank = rank
    }
}
