//
//  TestVcLocalRepository.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

class TestVcLocalRepository: TestVcRepository {
    typealias T = TestVCUiModel
    
    private let databaseManger: ArticlesDatabaseManager
    
    init(databaseManger:  ArticlesDatabaseManager) {
        self.databaseManger = databaseManger
    }
    
    func fetchList(completionHandler: @escaping ([TestVCUiModel]?, Error?) -> Void) {
        let details = databaseManger.getArticle().map({TestVCUiModel(description: $0.abstract,
                                                                    title: $0.headline?.main,
                                                                    date: $0.pubDate,
                                                                    imageUrl: $0.multimedia?.first?.url)})
        completionHandler(details, nil)
    }
   
}
