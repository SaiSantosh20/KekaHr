//
//  ArticlesDataRealmManager.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation
import RealmSwift

protocol ArticlesDatabaseManager {
    func storeArticle(data: [Doc])
    func getArticle() -> [Doc]
    func removeArticle()
}

class ArticlesRealmManager: ArticlesDatabaseManager, RelamSetupManager {
    func storeArticle(data: [Doc]) {
        self.removeArticle()
        var realmObjects: [ArticlesDataRealmObject] = []
        for object in data {
            let realmObject = self.fromCodable(object)
            realmObjects.append(realmObject)
        }
        write {
            realm.add(realmObjects)
        }
    }
    
    func getArticle() -> [Doc] {
        let realmObjects = realm.objects(ArticlesDataRealmObject.self)
            .sorted(byKeyPath: "pubDate", ascending: false)
        var articles: [Doc] = []
        for object in realmObjects {
            let doc = self.convertToDoc(realmObject: object)
            articles.append(doc)
        }
        return articles
    }
    
    func removeArticle() {
        let objects = realm.objects(ArticlesDataRealmObject.self)
        write {
            realm.delete(objects)
        }
    }
}





