//
//  TestVcNetworkManager.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

protocol TestVcNetworkManagerProtocol {
    var apiConfig: APIConfig { get }
    var apiFetcher: HTTPClient { get }
    func getArticlesList(completion: @escaping (Result<ArticlesData,HTTPError>) -> Void)
}

class TestVcNetworkManager: TestVcNetworkManagerProtocol {
    
    var apiConfig: APIConfig
    var apiFetcher: HTTPClient
    
    init(apiConfig: APIConfig, apiFetcher: HTTPClient) {
        self.apiConfig = apiConfig
        self.apiFetcher = apiFetcher
    }
}

extension TestVcNetworkManager {
    func getArticlesList(completion: @escaping (Result<ArticlesData,HTTPError>) -> Void) {
        var components = URLComponents()
        components.scheme = apiConfig.scheme
        components.host = apiConfig.host
        components.path = Routes.articlesearch.callAsFunction()
        guard let url = components.url,
              let urlRequest = apiFetcher.makeURLRequest(url: url,
                                                   method: HTTPMethod.GET.callAsFunction(),
                                                   headers: nil,
                                                   queryParams: [URLQueryItem(name: "q", value: "election"),
                                                                URLQueryItem(name: "api-key", value: "j5GCulxBywG3lX211ZAPkAB8O381S5SM")],
                                                   body: nil) else {
            completion(.failure(.invalidUrl))
            return
        }
        apiFetcher.request(request: urlRequest) { result in
            completion(result)
        }
    }
}
