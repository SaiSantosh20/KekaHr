//
//  TestVcRemoteRepository.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

class TestVcRemoteRepository: TestVcRepository {
    
    typealias T = TestVCUiModel
    
    private let networkManager: TestVcNetworkManagerProtocol
    private let databaseManager: ArticlesDatabaseManager
    
    
    init(networkManager: TestVcNetworkManagerProtocol, databaseManager: ArticlesDatabaseManager) {
        self.networkManager = networkManager
        self.databaseManager = databaseManager
    }
    
    func fetchList(completionHandler: @escaping ([TestVCUiModel]?, Error?) -> Void) {
        networkManager.getArticlesList {[weak self] result in
            switch result {
            case .success(let articles):
                let articlesData = articles
                var uimodel = articlesData.response?.docs?.map({TestVCUiModel(description: $0.abstract,
                                                                              title: $0.headline?.main,
                                                                              date: $0.pubDate,
                                                                              imageUrl: $0.multimedia?.first?.url)})
                let sortedObjects = uimodel?.sorted(by: { first, second in
                    guard let date1 = first.date?.toDate(format: "yyyy-MM-dd'T'HH:mm:ssZ"),
                         let date2 = second.date?.toDate(format: "yyyy-MM-dd'T'HH:mm:ssZ") else {
                           return false
                       }
                       return date1 > date2
                })
                    
                if let docs = articlesData.response?.docs,
                    docs.isEmpty == false {
                    self?.databaseManager.storeArticle(data: docs)
                }
                completionHandler(sortedObjects, nil)
            case .failure(let failure):
                completionHandler(nil, failure)
            }
        }
    }
}
