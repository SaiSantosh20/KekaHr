//
//  TestVcNetworkingRepository.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

protocol TestVcRepository {
    associatedtype T
    func fetchList(completionHandler: @escaping ([T]?, Error?) -> Void)
}

