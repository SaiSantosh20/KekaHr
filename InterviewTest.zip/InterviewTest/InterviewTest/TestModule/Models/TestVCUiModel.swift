//
//  TestVCUiModel.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation

struct TestVCUiModel: Codable {
    var description: String?
    var title: String?
    var date: String?
    var imageUrl: String?
}
