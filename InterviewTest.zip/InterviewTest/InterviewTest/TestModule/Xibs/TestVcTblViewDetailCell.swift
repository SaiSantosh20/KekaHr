//
//  TestVcTblViewDetailCell.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import UIKit

class TestVcTblViewDetailCell: UITableViewCell {

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var articleImgView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configureCell(model: TestVCUiModel?) {
        //debugPrint(model ?? "Something wrong cell model")
        self.dateLbl.text = model?.date?.toDate(format: "yyyy-MM-dd'T'HH:mm:ssZ")?.toString("MMM d, yyyy", timeZone: TimeZone.current)
        self.descriptionLbl.text = model?.description
        self.titleLbl.text = model?.title
        if let imageUrl = model?.imageUrl,
            let url = URL(string: imageUrl) {
            self.articleImgView.load(url: url, placeholder: UIImage(named: "noImageAvialable"))
        } else {
            self.articleImgView.image = UIImage(named: "noImageAvialable")
        }
       
    }
    
}
