//
//  TestVCViewModel.swift
//  InterviewTest
//
//  Created by AKASAPU SAI SANTOSH on 03/04/24.
//

import Foundation
import Combine

protocol TestVCViewModelDelegate: AnyObject {
    func reloadTheList()
    func updateNetwork(with status: Bool)
}

class TestVCViewModel {
    var repository: (any TestVcRepository)?
    
    var remoteRepository = TestVcRemoteRepository(networkManager: TestVcNetworkManager(apiConfig: APIConfig(scheme: "https",
                                                                                                            host: "api.nytimes.com"),
                                                                                       apiFetcher: UrlSessionAPIFetcher()),
                                                  databaseManager: ArticlesRealmManager())
    
    var localRepository = TestVcLocalRepository(databaseManger: ArticlesRealmManager())
    
    private let networkMonitor: NetworkReachability?
    private var cancellable : AnyCancellable?
    
    var articlesList: [TestVCUiModel] = []
    
    weak var delegate: TestVCViewModelDelegate?
    
    init() {
        networkMonitor = NetworkReachability()
    }
    
    func fetchDetails() {
        cancellable = networkMonitor?.isConnectedPublisher.sink {[weak self] status in
            debugPrint("Network status: \(status)")
            self?.delegate?.updateNetwork(with: status)
            if status {
                self?.repository = self?.remoteRepository
            } else {
                self?.repository = self?.localRepository
            }
            self?.repository?.fetchList(completionHandler: { info, error in
                if let info = info as? [TestVCUiModel] {
                    self?.articlesList = info
                    self?.delegate?.reloadTheList()
                }
            })
        }
    }
    
}
